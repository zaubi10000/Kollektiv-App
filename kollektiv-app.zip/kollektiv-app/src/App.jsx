import { useState } from "react";

function App() {
  const [input, setInput] = useState("");
  const [reflection, setReflection] = useState("");

  const analyzeFrequency = (text) => {
    if (text.toLowerCase().includes("angst")) {
      return "Deine Frequenz schwingt in Angst. Du willst Kontrolle, aber sehnst dich nach Halt.";
    } else if (text.toLowerCase().includes("klar")) {
      return "Du sendest Klarheit – aber du traust deiner eigenen Stimme noch nicht.";
    } else {
      return "Unklare Frequenz – bitte werde stiller und spüre, was du wirklich fühlst.";
    }
  };

  const handleSubmit = () => {
    const result = analyzeFrequency(input);
    setReflection(result);
  };

  return (
    <div style={{ maxWidth: 600, margin: '2rem auto', padding: '1rem' }}>
      <h1 style={{ textAlign: 'center' }}>KOLLEKTIV</h1>
      <p style={{ textAlign: 'center', color: '#666' }}>Frequenzspiegel für dein Feld</p>

      <textarea
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Was bewegt dich gerade? Sprich ehrlich."
        style={{ width: '100%', minHeight: 100, padding: 10 }}
      />
      <button onClick={handleSubmit} style={{ width: '100%', marginTop: 10 }}>
        Frequenz analysieren
      </button>

      {reflection && (
        <div style={{ marginTop: 20, padding: 10, backgroundColor: '#f4f4f4' }}>
          <p>{reflection}</p>
        </div>
      )}
    </div>
  );
}

export default App;